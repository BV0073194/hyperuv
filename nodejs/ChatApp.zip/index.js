const http = require("http");
const express = require("express");
const socketio = require("socket.io");
const path = require("path");
const app = express();
var server = require('http').createServer(app);
var socketIO = require('socket.io');
var request = require('request');

//app.set("status", "down");
app.get("status");
app.set('trust proxy', true);

var helmet = require('helmet');
//app.use(helmet.frameguard());

app.use(express.static('public'));
const httpserver = http.Server(app);
const io = socketio(httpserver);

const gamedirectory = path.join(__dirname, "html");

app.use(express.static(gamedirectory));

httpserver.listen(3000);

var rooms = [];
var usernames = [];
var roomnames = [];
var x = "";
app.get('/', (request, response) => {
  response.status(200).sendFile(__dirname + '/html/index.html');
});

app.get('/beta', (request, response) => {
  response.status(200).sendFile(__dirname + '/html/beta.html');
});

io.on('connection', function(socket){

  socket.on("join", function(room, username){
    if (username != "" && username.length < 400){
      rooms[socket.id] = room;
      usernames[socket.id] = username;
      socket.leaveAll();
      socket.join(room);
      socket.emit("join", room);
      io.in(room).emit("recieve", "Server -> " + username + " has entered the chat.");
    }
  })

  socket.on("room", function(room, username){
    console.log(room + " : " + username); 
  })

  socket.on("unjoin", function(room, username){
    if (username != ""){
      rooms[socket.id] = room;
      usernames[socket.id] = username;
      socket.leaveAll();
      io.in(room).emit("recieve", "Server -> " + username + " has left the chat.");
    }
  })

  socket.on("send", function(message, username){
    io.in(rooms[socket.id]).emit("recieve", usernames[socket.id] + " => " + message);
  })

  socket.on("recieve", function(message){
    socket.emit("recieve", message);
  })
})
