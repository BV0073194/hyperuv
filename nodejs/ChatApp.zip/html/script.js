var socket;
var usernameInput;
var chatIDInput;
var messageInput;
var chatRoom;
var dingSound;
var messages = [];
var user;
var delay = true;
var usernames = [];

function onload(){
  socket = io();
  usernameInput = document.getElementById("NameInput");
  chatIDInput = document.getElementById("IDInput");
  messageInput = document.getElementById("ComposedMessage");
  chatRoom = document.getElementById("RoomID");
  dingSound = document.getElementById("Ding");

  socket.on("join", function(room){
    chatRoom.innerHTML = "Chatroom : " + room;
    socket.emit("room", chatIDInput.value, usernameInput.value);
  })

  socket.on("recieve", function(message, username){
    usernames[socket.id] = username;
    console.log(message);
    if (messages.length < 9){
      messages.push(message);
      dingSound.currentTime = 0;
      dingSound.play();
    }
    else{
      messages.shift();
      dingSound.currentTime = 0;
      dingSound.play();
      messages.push(message);
    }
    for (i = 0; i < messages.length; i++){
      document.getElementById("Message"+i).innerHTML = messages[i];
      document.getElementById("Message"+i).style.color = "#04d13b";
    }
  })
}

function Connect(){
  if(usernameInput.value.length < 401){
    socket.emit("join", chatIDInput.value, usernameInput.value);
  }
  else{
    window.alert("please limit characters to 400.")
  }
}

function Disconnect(){
  socket.emit("unjoin", chatIDInput.value, usernameInput.value);
}

function Send(){
  if(messageInput.value.length < 401){
    if (delay && messageInput.value.replace(/\s/g, "") != ""){
      delay = false;
      setTimeout(delayReset, 1000);
      socket.emit("send", messageInput.value);
      messageInput.value = "";
    }
    elif
  }
  else{
    window.alert("please limit characters to 400.")
  }
}

function delayReset(){
  delay = true;
}