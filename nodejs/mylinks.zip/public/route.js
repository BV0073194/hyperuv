function rlink(){
  window.location.reload(true)
}

function oldver(){
  window.open("https://mylinks-legacy.proxyxyz.repl.co", "_self");
}