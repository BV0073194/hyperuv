function ttlink()
{
 window.open("https://www.tiktok.com/@_mariia__clara_", "_blank");
}
function iglink()
{
 window.open("https://instagram.com/_mariiia__clara_?utm_medium=copy_link", "_blank");
}
function iglink1()
{
 window.open("https://instagram.com/__mmarih__?utm_medium=copy_link", "_blank");
}