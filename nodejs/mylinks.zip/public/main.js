function udlink()
{
 window.open("https://replit.com/@proxyxyz/mylinks", "_blank");
}

//----------------------------------------


