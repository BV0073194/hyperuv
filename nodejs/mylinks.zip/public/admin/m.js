function down()
{
 window.open("https://mylinks.proxyxyz.repl.co/admin/status-down", "_blank");
}
function up()
{
 window.open("https://mylinks.proxyxyz.repl.co/admin/status-up", "_blank");
}

function quit()
{
 window.exit();
}
//----------------------------------------


