function ttlink()
{
 window.open("https://vm.tiktok.com/ZMdcVD8Kx/", "_blank");
}
function iglink()
{
 window.open("https://instagram.com/bv0073194?utm_medium=copy_link", "_blank");
}
