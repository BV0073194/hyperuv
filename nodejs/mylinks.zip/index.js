'use strict';
var express = require('express');
var app = express();
var server = require('http').createServer(app);
var socketIO = require('socket.io');
var io = socketIO(server);
var request = require('request');

//app.set("status", "down");
app.get("status");
app.set('trust proxy', true);

var helmet = require('helmet');
//app.use(helmet.frameguard());

app.use(express.static('public'));

io.on('connection', function(Socket) {
  var sessionID = Socket.id;
});

server.listen(8080);

console.log("This is pid " + process.pid);

if(app.get("status") == "down"){
  app.get('/', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/route.html');
  });
  app.get('/status', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/route.html');
  });
  app.get('/bv0073194', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/route.html');
  });
  app.get('/maria', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/route.html');
  });
  app.get('/clara', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/route.html');
  });
  app.get('/admin', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/admin/admin.html');
  });
  app.get('/admin/status-up', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/admin/status-up.html');
    console.log("Server.Status: UP");
    app.set("status", "up");
    console.log(app.get("status"));
    process.on("exit", function () {
        require("child_process").spawn(process.argv.shift(), process.argv, {
            cwd: process.cwd(),
            detached : true,
            stdio: "inherit"
        });
    });
    process.exit();       
  });
  app.get('/admin/status-down', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/admin/status-down.html');
    console.log("Server.Status: DOWN");
    app.set("status", "down");
    console.log(app.get("status"));
    process.on("exit", function () {
        require("child_process").spawn(process.argv.shift(), process.argv, {
            cwd: process.cwd(),
            detached : true,
            stdio: "inherit"
        });
    });
    process.exit();   
  });
}
else{
  app.get('/', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/main.html');//'/public/main.html');
  });
  app.get('/maria',(request, response) => {
    response.status(200).sendFile(__dirname + '/public/maria.html');
  });
  app.get('/clara',(request, response) => {
    response.status(200).sendFile(__dirname + '/public/maria.html');
  });  
  app.get('/BV0073194', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/bv0073194.html');
  });
  app.get('/admin', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/admin/admin.html');
  });
  app.get('/admin/status-up', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/admin/status-up.html');
    console.log("Server.Status: UP");
    app.set("status", "up");
    console.log(app.get("status"));
    process.on("exit", function () {
        require("child_process").spawn(process.argv.shift(), process.argv, {
            cwd: process.cwd(),
            detached : true,
            stdio: "inherit"
        });
    });
    process.exit();         
  });
  app.get('/admin/status-down', (request, response) => {
    response.status(200).sendFile(__dirname + '/public/admin/status-down.html');
    console.log("Server.Status: DOWN");
    app.set("status", "down");
    console.log(app.get("status"));
    process.on("exit", function () {
        require("child_process").spawn(process.argv.shift(), process.argv, {
            cwd: process.cwd(),
            detached : true,
            stdio: "inherit"
        });
    });
    process.exit();        
  });
}
