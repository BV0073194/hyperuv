# HypertabsEX
Basically just https://github.com/luphoria/hypertabsEX except everything is updated and it now uses UV

# I DID NOT MAKE THIS
This is simply a reverse engeneer of https://titaniumnetwork.org/ which DOES NOT belong to me.





# Deployment
[![Deploy to Heroku](https://raw.githubusercontent.com/BinBashBanana/deploy-buttons/master/buttons/remade/heroku.svg)](https://heroku.com/deploy/?template=https://github.com/illusionTBA/HypertabsEX)
[![Run on Replit](https://raw.githubusercontent.com/BinBashBanana/deploy-buttons/master/buttons/remade/replit.svg)](https://replit.com/github/illusionTBA/HypertabsEX)
[![Remix on Glitch](https://raw.githubusercontent.com/BinBashBanana/deploy-buttons/master/buttons/remade/glitch.svg)](https://glitch.com/edit/#!/import/github/illusionTBA/HypertabsEX)






