# cookieclicker

Original game can be found [here](http://orteil.dashnet.org/cookieclicker/).
This version has no ads and can be used anywhere.