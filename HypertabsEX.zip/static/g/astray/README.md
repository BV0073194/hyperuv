# Astray

A WebGL maze game built with Three.js and Box2dWeb.


### License

I don't believe in them. You can order your bits however you please.