const internal_pages = {
    // YOU MUST ADD YOUR INTERNAL PAGE TO THIS FILE IF YOU WANT IT TO WORK!
    // This index is how HT can reference what page to what file
    newtab: "/internal/newTab/main.html",
    extensionsmarketplace: "/internal/extensions/marketplace.html",
    extensions: "/internal/extensions/index.html",
    games: "/internal/g/index.html"
}
